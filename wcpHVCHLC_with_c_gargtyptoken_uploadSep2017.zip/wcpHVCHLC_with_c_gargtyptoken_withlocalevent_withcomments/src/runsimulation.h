#ifndef RUN_SIMULATION_H
#define RUN_SIMULATION_H

#include <vector>
#include <string>
#include <sstream>
#include <numeric>
#include <random>
#include <algorithm> // for for_each

#include "Process.h"

#define RAND_UNICAST 1

using namespace std;  

extern int number_of_processes;   // number of processes/nodes

extern int delta;          // minimum message delay      
extern int epsilon;       // uncertainty windows
extern int delta_max;  
extern double alpha;     // message rate

extern int run_up_to; // total number of physical clock cycles in simulation
extern int absolute_time;      // index of physical clock cycles

extern probability_matrix prob_matrix;

extern int snapshotCount;
extern set<Token> snapshotAll;
extern set<hlcToken> hlcsnapshotAll;

extern vector<vector<int>> global_tracker;
extern vector<int> global_common;
extern int hlc_false_negatives;
extern int hvcSnaps;
extern int hlcSnaps;
extern int hlcSnapsSize;
extern int glob_true_interval;
/*
distance_matrix D;
string topology_file_name;
string prob_matrix_file_name;
*/

class RunSimulation{
public:
  static vector<Process> InitProcess();
  static vector<int> run(int type, const string& s);
  static void RandomUnicastExperimentSnapshot(const string& s);
	// check for hlc global true state 
	//static int ProcessHLCtrueGlobalCheck(HLC currenttruepoint,int id);
};

#endif
