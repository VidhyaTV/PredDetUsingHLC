/*
  runsimulation.cpp - implementation of runsimulation class
*/

#include "runsimulation.h"

int snapshotCount = 0;    	// number of snapshot found by Garg's algorithm
int hlcsnapshotCount = 0; 	// number of snapshot found by Garg's algorithm
set<Token> snapshotAll;   	// set of all snapshots true according to Garg's algorithm.
                          	// elements/snapshots are sorted according to their maximum time difference
                          	// within the snapshot
set<hlcToken> hlcsnapshotAll; 	// has all process's candidates at that point in time and 
				// the process's id whose candidate overlapped with all other process's candidates
 
/* 
  InitiProcess() - initialize all processes with ID starting from 0
*/
vector<Process> RunSimulation::InitProcess() {
	vector<Process> vp;
	for (int i = 0; i < number_of_processes; i++) {
    	// Duong: here Process(i) is constructor
		vp.push_back(Process(i));
	}
	return vp;
}

/*
  InitiAllConfiguration() - initialize simulation paramters from input file
                            initialize global variables
*/
void InitAllConfiguration(const string& parameter_file_name) {
	/*Code for HVC bound-Sorrachai
	int i;
	ifstream in(parameter_file_name);   // param input file
	string content;
	if (!in.is_open()) {
		printf("Error: can't open parameter file\n");
		exit(1);
	}
	*/
	//Code for HVC bound-Sorrachai
	delta_max = delta;
	D = Utility::AllPairShortestPaths(Utility::ReadGraph(topology_file_name));
	prob_matrix = Utility::ReadProbabilityMatrix(prob_matrix_file_name);
	
	#ifdef _DEBUG
	// init debug output file-Duong
	debug_candidate = vector<ofstream>(number_of_processes);
	for(int i = 0; i < number_of_processes; i++){
	debug_candidate.at(i).open("debug/wcp_debug_candidate_" + std::to_string(i));
	}
	#endif

	/* initialize global token for HVC-Duong*/
	globalToken.setPid(0);    // process 0 will have global token first
	// mark all candidate as invalid
	globalToken.setColor(vector<int>(number_of_processes, RED));
	// set initial value for each process' candidate
	globalToken.setSnapshot(vector<Candidate>(number_of_processes, Candidate()));
	for(int i = 0; i < number_of_processes; i++)
	{
		HVC initTs = HVC(vector<int>(number_of_processes, -1*epsilon-1),1);
		Candidate initCand = Candidate(i, 0, initTs);
		globalToken.setProcessCandidate(initCand, i);
	}

	/* initialize hlc global token for HLC*/
	hlcglobalToken.sethlcPid(0);    // process 0 will have HLC global token first
	// mark all candidate as invalid
	// set initial value for each process' candidate
	hlcglobalToken.sethlcSnapshot(vector<hlcCandidate>(number_of_processes, hlcCandidate()));
	for(int i = 0; i < number_of_processes; i++)
	{
		HLC initTs = HLC(vector<int>(2, -1)); 	//object of the HLC class initialized with -1 for l & c values
		hlcCandidate initCand = hlcCandidate(i, 0, initTs,initTs);//object of class hlccandidate initialized with default 
							//interval start and end, i.e.-1 for l & c for the start and end HLC values
		hlcglobalToken.sethlcProcessCandidate(initCand, i);	//set hlc global token with default intervals
									//(-1,-1)to(-1,-1) as each process's candidate   
	}  
}

vector<int> RunSimulation::run(int type, const string& s){
	
	vector<int> maxTimeDiffList; // historgram for maximum time difference
	ofstream wcp_compare_out("wcp_compare",ios::out | ios::app);  // output file containing global snapshot of weak conjunctive predicate
	ofstream wcp_out("debug/wcp_out");  // output file containing global snapshot of weak conjunctive predicate
	InitAllConfiguration("parameters.in.linux");//setup all required initial configuration-HLC's global token, HVC's global token
	vector<Process> vp = InitProcess();//create required(number_of_processes) number of objects of type Process

	snapshotCount = 0;//number of hvc snapshots
	hlcsnapshotCount = 0;//number of hlc snapshots

	// clear stored snapshots at the start of each simulation
	snapshotAll.clear();
	hlcsnapshotAll.clear();//

	/*variables for counting HVC snapshots based on interval size*/
	Token tn; 		//of type HVC global token
	bool first=false; 	// variable to remember first HVC snapshot detection
	bool success=false; 	//variable to remember last counted HVC snapshot based on global interval size
	/*variables for counting HLC snapshots based on interval size*/
	vector<hlcCandidate> otn;//of type HLC-global-token/vector of hlccandidates
	bool ftime=true;	// variable to remember first HLC snapshot detection
	bool success1=false; 	//variable to remember last counted HLC snapshot based on global interval size
    	
	// simulation main loop 
 
	for (absolute_time = 0; absolute_time < run_up_to; absolute_time++) //for every run, abbsolute time is like every click of the clock
	{	
		for_each(begin(vp), end(vp), [](Process& p) {p.UnlockTime(); p.ReceiveMsg(); });//for each process in the vector of processes:
												//set time_locked=false=>for updating process's phy time,
												//receive messages 
		for_each(begin(vp), end(vp), [&vp, &type](Process& p)//for each process in the vector of processes:
		{
			// sending message according to desired distribution
			switch(type)
			{
				case RAND_UNICAST:			
					p.SendMsg(vp[Utility::GetIndexOfWeightedRandom(prob_matrix[p.GetId()])]);
					break;
				default:
					break;
	    		}
		});	

		//for each process in the vector of processes: perform dummy local event which just updates HLC values of the process

		for_each(begin(vp), end(vp), [](Process& p) { p.UpdateLocalEvent(); });	

		// for Garg's algorithm //[list of variables to be used inside the for loop]
		
		for_each(begin(vp), end(vp), [&vp, &wcp_compare_out, &maxTimeDiffList,&tn,&first,&success,&success1,&ftime,&otn](Process& p) 
		{
			// At each time, process will randomly generate candidate,
			 //i.e. states where local predicates are true.
			p.RandGenCand();
			// At each clock cycle, process will check to see if it has the global token
			// by matching its ID and token's ID
			//   If match: process the token
			 //  If not match: do nothing
			if(p.GetId() == hlcglobalToken.gethlcPid())
			{
			    if(p.ProcesshlcGlobalToken() == HLC_WCP_DETECTED)//if a snapshot was detected
			    {	
				hlcglobalToken.sethlcPid(p.GetId());	//set the process ID in the token whose candidate interval
									//overlapped with other processes' candidate intervals				
				hlcsnapshotAll.insert(hlcglobalToken);	//add the toke on to the set of snapshots
				hlcglobalToken.printToken(wcp_compare_out);//print the token
				if(!ftime)//if not the first detected snapshot
				{
					for(int j = 0; j < number_of_processes; j++)//for each process
					{
						//in the newly detected snapshot - get the l value at the interval start of the jth process's candidate
						int newtk=hlcglobalToken.gethlcSnapshot().at(j).getinterval_begin().getHLCElement(0);
						//in the previously counted snapshot - get the l value at the interval start of the jth process's candidate
						int oldtk=otn.at(j).getinterval_begin().getHLCElement(0);
						//if the l values are far apart than the size of the interval then count the new snapshot
						if(std::abs(oldtk-newtk)>glob_true_interval)
						{	
							//set flag that the newly detected snapshot was counted
							success1=true;	
							//print the counted token with "was accepted" tag onto the file
							wcp_compare_out<<"was accepted\n";
							//increment snapshot counter	
							hlcsnapshotCount++;
							break;
						}
					}
			
					if(success1)// if the newly detected snapshot was counted
					{
						//remember the newly detected snapshot as the previously counted snapshot
						otn=hlcglobalToken.gethlcSnapshot();
						//reset the variable that remembers acceptance
						success1=false;
					}
				}
				else//if it is the first detected snapshot - then count it
				{
					wcp_compare_out<<"was accepted\n";//print the counted token with "was accepted" tag onto the file
					ftime=false;//remember that the first snapshot was found already
					otn=hlcglobalToken.gethlcSnapshot();//remember the first detected snapshot as the previously counted snapshot
					hlcsnapshotCount++; //increment snapshot counter
				}

				hlcglobalToken.hlcresetSmallest();//find the process with smallest logical clock and it as the next owner of the token
			    }
			}
			// At each clock cycle, process will check to see if it has the global token
			// by matching its ID and token's ID
			//   If match: process the token
			 //  If not match: do nothing
			if(p.GetId() == globalToken.getPid())
			{
			    if(p.ProcessGlobalToken() == WCP_DETECTED)
			    {
			      // write out the snapshot to output file			      
			      #ifdef _DEBUG              
			      wcp_out << endl << endl << "***** snapshot "<< snapshotCount << ":" << endl;          
			      globalToken.printToken(wcp_out);              
			      #endif    
			      //globalToken.printToken(wcp_compare_out); 
			      // record this token
			      snapshotAll.insert(globalToken); 

				/*recalculating HVC tokens taking intervals into account*/
				
				success=false;

				//snapshotCount ++;
				if(!first)
				{
					snapshotCount ++;
					globalToken.printToken(wcp_compare_out);
					tn.setSnapshot(globalToken.getSnapshot());
					first=true;
				}
				else{
					for(int j = 0; j < number_of_processes; j++)
					{
						int newtk=globalToken.getSnapshot().at(j).getTimestamp().getHVC().at(j);
						int oldtk=tn.getSnapshot().at(j).getTimestamp().getHVC().at(j);
						//cout<<"glob_true_interval"<<glob_true_interval<<"\n";
						if(std::abs(newtk-oldtk)>glob_true_interval)
						{
							success=true;
							globalToken.printToken(wcp_compare_out); 				
							snapshotCount ++;
							break;
						}
					} 
				}  	
				if(success)
				{				
				tn.setSnapshot(globalToken.getSnapshot());
				}

			      maxTimeDiffList.push_back(globalToken.getMaxTimeDiff());			      
			      // in new implementation, we set the process with smallest clock to be RED
			      globalToken.reset();
			    }
			}
        	});
	}
	hvcSnaps=snapshotCount;

	cout<<"hlcsnapshotAllTotal:"<<hlcsnapshotAll.size()<<"\n";

	hlcSnaps=hlcsnapshotCount;

    #ifdef _DEBUG
    
    cout << "maxTimeDiffList.size() = " << maxTimeDiffList.size() << endl;
    
    #endif
   
    return maxTimeDiffList;
  
}

