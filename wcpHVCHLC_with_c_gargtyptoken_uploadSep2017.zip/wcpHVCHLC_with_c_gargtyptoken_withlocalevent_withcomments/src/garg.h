/*
  garg.h - data structures for Garg's algorithm
           e.g. Candidate, GlobalToken
*/

#ifndef GARG_H
#define GARG_H

#include <fstream>
#include "clock.h"

using namespace std;

/* 
  constants
*/

// color of token
#define RED   1
#define GREEN 0

// program exit code
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1

// detection of WCP
#define WCP_DETECTED          1
#define WCP_NOT_YET_DETECTED  0

// detection of WCP by HLC
#define HLC_WCP_DETECTED          1
#define HLC_WCP_NOT_YET_DETECTED  0

// function execution return
#define OK  0
#define ERR 1

// global snapshot consistency
#define CONSISTENT      0
#define NOT_CONSISTENT  1

extern int number_of_processes;

/*
  Candidate - class for local state proposed by a process for global snapshot at that process
*/

class Candidate{
private:
  int procId;     // this candidate belongs to which process
  int candId;     // ID of this candidate among the process's proposals
                  // candId = 0 is for initialization in global token
                  // candidates created by process should start with 1

  HVC timestamp;  // timestamp of the candidate (should support both HVC and vector clock)

public:
  // default constructor should not be called since its candId is not managed  
  Candidate(){}

  // prefered constructor
  Candidate(int pid, int cid, const HVC & someHvc){
    procId = pid;
    candId = cid;
    timestamp = someHvc;
  }
  
  // gets and sets

  int getProcId() const {
    return procId;
  }

  int getCandId() const {
    return candId;
  }

  HVC getTimestamp() const {
    return timestamp;
  }

  void setProcId(int pid){
    procId = pid;
  }

  void setCandId(int cid){
    candId = cid;
  }

  void setTimestamp(HVC ts){
    timestamp = ts;
  }

  // print information
  void print(ostream&);

};
 
 
/*
  Token - class for global token that will be passed around red processes
*/

class Token{
private:
  int pid;    // ID of process who will have this token
              // pid >= 0: color of process pid is red. That process will have the token
              // pid = -1 to signal all processes are green

  // snapshot of the system = an array of candidates proposed by all processes
  // snaphost.at(i) is for candidate from process i
  // init:  snapshot.at(i): procId = i; candId = 0;
  //        HVC for all elements = 0 except element i = 1 or epsilon
  //        or HVC for all elements = 0
  vector<Candidate> snapshot;

  // color array to see if a process is red or green
  // color.at(i) is color for process i
  // init: all colors = RED
  vector<int> color;

public:
  // gets and sets
  
  int getPid() const {
    return pid;
  }
  vector<Candidate> getSnapshot() const {
    return snapshot;
  }
  vector<int> getColor() const {
    return color;
  }
  
  void setPid(int p){
    pid = p;
  }
  
  void setSnapshot(const vector<Candidate> &sns){
    snapshot = sns;
  }
  
  void setProcessCandidate(const Candidate cand, int whichProcess){
    snapshot.at(whichProcess) = cand;
  }
  
  void setColor(const vector<int> cl){
    color = cl;
  }
  
  void setProcessColor(const int cl, int whichProcess){
    color.at(whichProcess) = cl;
  }

  /*
    Token::getMaxTimeDiff() - get the maximum difference in HVC time between any pair of processes in the snapshot
  */

  int getMaxTimeDiff() const {
    int i;
    int max, min;

    // compute maximum physical time difference between all pairs of processes within the snapshot
    max = min = snapshot.at(0).getTimestamp().getHVC().at(0);
    for(i = 1; i < number_of_processes; i++){
      int temp = snapshot.at(i).getTimestamp().getHVC().at(i);

      if(max < temp)
        max = temp;
      if(min > temp)
        min = temp;
    }
    
    return (max-min);
    
  }
  
  // a comparison operator between snapshot
  // return true if your maximum time difference in your snapshot is smaller
  //        false otherwise
  bool operator < (const Token& they) const {
    return getMaxTimeDiff() < they.getMaxTimeDiff();
  }
  
  int checkPhysicalConsistent(int epsilon);
  void printToken(ofstream & os);
  void reset();
  void resetSmallest();
};
class hlcsnaps{
private:
	
	int c1;
	int l2;
	int c2;
public:
int l1;
// preferred constructor
  hlcsnaps(const int l_1,const int c_1,const int l_2,const int c_2){
	l1=l_1;
	c1=c_1;
	l2=l_2;
	c2=c_2;
  }
  // print information
  void print(ofstream &);
bool operator < (const hlcsnaps& hs) const 
{
   return l1 < hs.l1;  //assume that you compare the record based on a
}
};

class hlcCandidate{
private:
  int hlcprocId;     // this candidate belongs to which process
  int hlccandId;
  HLC interval_begin;// hlc candidate that has the start and end of interval in which the process had true predicate
  HLC interval_end;

public:
  // default constructor should not be called since its candId is not managed  
  hlcCandidate(){}

  // preferred constructor
  hlcCandidate(int pid, int cid, HLC start_intvl, HLC end_intvl){
    hlcprocId = pid;
    hlccandId = cid;
    interval_begin = start_intvl;
    interval_end = end_intvl;
  }
  
  // gets and sets
  int gethlcProcId() const {
    return hlcprocId;
  }

  int gethlcCandId() const {
    return hlccandId;
  }

  void sethlcProcId(int pid){
    hlcprocId = pid;
  }

  void setCandId(int cid){
    hlccandId = cid;
  }

  HLC getinterval_begin() const {
    return interval_begin;
  }

  HLC getinterval_end() const {
    return interval_end;
  }

  void setinterval_begin(const HLC start_intvl){
    interval_begin = start_intvl;
  }

  void setinterval_end(const HLC end_intvl){
    interval_end = end_intvl;
  }

  // print information
  void print(ostream&);


bool operator<(const hlcCandidate& rhs) const 
{
   return hlccandId < rhs.hlccandId;  //assume that you compare the record based on a
}

};

/*
  Token - class for global token that will be passed around red processes
*/

class hlcToken{
private:
  int hlcpid;    // ID of process who will have this token
              // pid >= 0: color of process pid is red. That process will have the token
              // pid = -1 to signal all processes are green

  // snapshot of the system = an array of candidates proposed by all processes
  // snaphost.at(i) is for candidate from process i
  // init:  snapshot.at(i): procId = i; candId = 0;
  //        HVC for all elements = 0 except element i = 1 or epsilon
  //        or HVC for all elements = 0
  vector<hlcCandidate> hlcsnapshot;

public:
  // gets and sets
  
  int gethlcPid() const {
    return hlcpid;
  }
  vector<hlcCandidate> gethlcSnapshot() const {
    return hlcsnapshot;
  }
  void sethlcPid(int p){
    hlcpid = p;
  }
  
  void sethlcSnapshot(const vector<hlcCandidate> &sns){
    hlcsnapshot = sns;
  }
  
  void sethlcProcessCandidate(const hlcCandidate cand, int whichProcess){
    hlcsnapshot.at(whichProcess) = cand;
  }
  void printToken(ofstream & os);
  void hlcreset();
  void hlcresetSmallest();
bool operator<(const hlcToken& rhs) const 
{
   return hlcsnapshot < rhs.hlcsnapshot;  //assume that you compare the record based on a
}
};


