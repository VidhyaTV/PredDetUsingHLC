
#include <random>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <fstream>

using namespace std;

#include "Process.h"


/* send message to a set of processes */

void Process::BroadcastMsg(vector<Process>& vp) {
	for (int k = 0; k < number_of_processes; k++) {
		if (k != id) SendMsg(vp[k]);
	}
}

/* send message to a process */
void Process::SendMsg(Process& k)  {
	//cout<<"send message\n";
	my_time_now = GetTimeNow();
	RefreshClock();
	//send message based on alpha or communication frequency
	if (Utility::GetRandomNumberInRange(1, 100)*1.0 <= alpha * 100) {
		//code for HVC bound -Sorrachai    		
		// D is distance matrix
		int distance = D[id][k.id];
		int time_delay_msg = 0;
		for (int i = 0; i < distance; i++) {
			time_delay_msg += PhysicalTime::GetDelayMessageTime();
		}
		CountActiveSize();
		int as = CountActiveSizeNow();
		augmented_time.setActiveSize(as);

		//HLC algorithm		
		vector<int> lc=logical_time.getHLC();	//get the current HLC value(l and c) of the process
		int l_final=lc[0];			//buffer variable for the l value	
		lc[0]=max(l_final,my_time_now);		//l is assigned to the max among process' l or the physical time
		if(lc[0]==l_final)			//if the updated l was obtained from the previous l value
		{	lc[1]=lc[1]+1;			//increment the c value by 1
		}
		else					//if the updated l was obtained from the physical time
		{	lc[1]=0;			//reset the c value		
		}
		//logical_time.setHLCElement(lc[0],0);	
		//logical_time.setHLCElement(lc[1],1);
		logical_time.setHLC(lc);		//update process' hlc value
		true_interval=0;			//end the interval in case of communication
		k.PushMsg(message(time_delay_msg + absolute_time,augmented_time, logical_time.getHLC(), id));//push the message to process k's mailbox with updated hlc
	}
}

/*local event that updates process' HLC*/
void Process::UpdateLocalEvent()  {
	//cout<<"localevent\n";	
	my_time_now = GetTimeNow();		//get physical time
	//HLC algorithm		
	vector<int> lc=logical_time.getHLC();	//get the current HLC value(l and c) of the process
	int l_final=lc[0];			//buffer variable for the l value	
	lc[0]=max(l_final,my_time_now);		//l is assigned to the max among process' l or the physical time
	if(lc[0]==l_final)			//if the updated l was obtained from the previous l value
	{	lc[1]=lc[1]+1;			//increment the c value by 1
	}
	else					//if the updated l was obtained from the physical time
	{	lc[1]=0;			//reset the c value		
	}
	//logical_time.setHLCElement(lc[0],0);	
	//logical_time.setHLCElement(lc[1],1);
	logical_time.setHLC(lc);		//update process' hlc value
}

/*code for HVC bound -Sorrachai */
void Process::CountActiveSize()  {
	int count_active = 0;
	for (int i = 0; i < augmented_time.getHVC().size(); i++) {
		if (augmented_time.getHVC()[i] > my_time_now - epsilon) {
			count_active++;
		}
	}
// Duong: perhaps we only push size of active count into history 
//        after we have passed the uncertainty period (i.e. epsilon)
	if(absolute_time > epsilon) size_of_at_history.push_back(count_active);
}
/*code for HVC bound -Sorrachai */
int Process::CountActiveSizeNow()  {
	//cout<<"countactivesize\n";
	my_time_now = GetTimeNow();
	
	RefreshClock();
	int count_active = 0;
	for (int i = 0; i < augmented_time.getHVC().size(); i++) {
		if (augmented_time.getHVC()[i] > my_time_now - epsilon) {
			count_active++;
		}
	}
	return count_active;
}

/*receive messages */
void Process::ReceiveMsg(){
	//cout<<"receive message\n";
	//read only those messages that have arrival time less than current physical time
	if (!mail_box.empty() && begin(mail_box)->arrival_time <= PhysicalTime::GetAbsoluteTime()) {
		my_time_now = GetTimeNow();				//get physical time
		RefreshClock();
		int size_now = CountActiveSizeNow();			//code for HVC bound -Sorrachai
		//read all messages that have arrival time less than current physical time
		while (!mail_box.empty() && begin(mail_box)->arrival_time <= PhysicalTime::GetAbsoluteTime()) 
		{
			auto m_itr = begin(mail_box);			//pointer to message
			vector<int> m_at = m_itr->sender_at.getHVC();	//get sending process' HVC
			for (int i = 0; i < (int)m_at.size(); i++) {	//updating HVC
			augmented_time.getHVC()[i] = max(m_at[i], augmented_time.getHVC()[i]);
			}
			
			/**HLC**/
			vector<int> message_lc= m_itr->lsender_at.getHLC();//get sending process' hlc	
			vector<int> lc=logical_time.getHLC();		//process' hlc
			int l_final, buffvar;
			l_final=lc[0];					//store l value's copy as l_final
			buffvar=max(message_lc[0],my_time_now);		//get max over sender's l present in the message 
									//and current physical time, and store it as buffvar
			lc[0]=max(l_final,buffvar);			//get max over process' l and buffvar, 
									//and update the process' l to it
			
			if((lc[0]==l_final)&&(lc[0]==message_lc[0]))	//if the new l value is same as old l value
			{						//and the sender's l value
				lc[1]=max(lc[1],message_lc[1])+1;	//then find the max value among the sender's c 
									//and process', and update the process' c to this plus one
				//cout<<"All are equal\n";	
			}
			else if(lc[0]==l_final)				//if the new l value is same as the old l value
			{
				lc[1]=lc[1]+1;				//then increment c by 1
				//cout<<"Got from older value\n";		
			}
			else if(lc[0]==message_lc[0])			//if the new l value is same as the 
			{						//sender's l value in the message then
				lc[1]=message_lc[1]+1;			//set c to the sender's c plus 1
				//cout<<"Got from message\n";
			}
			else						//if the new l value was obtained from the physical time
			{	//cout<<"Got from phy time\n";	
				lc[1]=0;				//then reset c value to 0
			}
			logical_time.setHLC(lc);			//update the process' HLC with these new l and c values
			//cout<<"after receiving hlc stamped with "<<"("<<logical_time.getHLC()[0]<<":"<<logical_time.getHLC()[1]<<") for Process"<<id<<"\n";
			mail_box.erase(m_itr);				//erase the read message
		}							//end of while
		true_interval=0;					//end interval when communication happens
		//code for HVC bound -Sorrachai 		
		CountActiveSize();
	}
}

void Process::PushMsg(const message& m){
	mail_box.insert(m);
}
int Process::GetTimeNow() const {
	
	if (time_locked) 
	{
		//cout<<my_time_now<<"\n";
		return my_time_now;
	}
	else
	{
		//cout<<max(my_time_now+1,PhysicalTime::GetTimeNow())<<"\n";
		return max(my_time_now+1,PhysicalTime::GetTimeNow());
	}

}

// RefreshClock is called whenever process sends or receives messages

void Process::RefreshClock() {
	if (time_locked) return;
	
	for (int i = 0; i < (int)augmented_time.getHVC().size(); i++) {
		if (i == id) continue;
		if (augmented_time.getHVC()[i] < my_time_now - epsilon ) {
			augmented_time.setHVCElement(my_time_now - epsilon, i);
		}
	}
	augmented_time.setHVCElement(my_time_now, id);
	
	time_locked = true;
}

// For Garg's algorithm

/*
  Process:RandGenCand() - randomly generate a candidate:
    randomly generate a number.
    If the number <= pre-determined rate
	HVC:	Create new candidate at current timestamp
		Push the candidate into candiate queue
	HLC:	Remember the HLC value as the interval start point
    Else
	HVC:	do nothing
	HLC:	if an interval has started end it and store the interval as a candidate
*/
int Process::RandGenCand(){

	//if the previous interval has ended
	if(true_interval<=0)
	{
		// create a new candidate and push it into the queue
		if(Utility::GetRandomNumberInRange(1, 100)*1.0 <= localPredRate * 100)
		{
			/*pushing HVC candidate*/
			//cout<<"true for Process:"<<id<<" at "<<logical_time.getHLC()[0]<<":"<<logical_time.getHLC()[1]<<"\n";
			Candidate newCand = Candidate(id, ++candCount, augmented_time);
			candidateQueue.push(newCand);
			#ifdef _DEBUG
			// print candidate to debug file
			newCand.print(debug_candidate.at(id));
			debug_candidate.at(id) << endl; 
			#endif	

			/*computing HLC interval candidate*/
			//set interval size to the global interval size provided in simulation.sh
			true_interval=glob_true_interval;
			
			if(first_true_logical_time.getHLCElement(0)!=-1) //if previous true interval was not recorded already
			{	
				if((first_true_logical_time.getHLCElement(0)!=logical_time.getHLCElement(0))||(first_true_logical_time.getHLCElement(1)!=logical_time.getHLCElement(1)))
				{		
					hlcCandidate hlcNewCand = hlcCandidate(id, ++hlcCandCount, first_true_logical_time,logical_time);//create new interval candidate
					hlcCandidateQueue.push(hlcNewCand);	// push the hlc interval candidate into the candidate queue
					new_true_start=false;			// reset interval start
					
					first_true_logical_time.setHLCElement(-1,0);
					first_true_logical_time.setHLCElement(-1,1);

				}
			}
			else
			{
				//remember the current logical time as the first_true_logical_time to mark the interval start point
				first_true_logical_time=logical_time;
			}
			//set to true if a new true starting point for the inetrval is obtained
			new_true_start=true;
			return 1;
		}
		else
		{
			//if an interval has started and the HLC value corresponding to the start point is set (not the default value)
			if(((first_true_logical_time.getHLCElement(0)!=-1)||(first_true_logical_time.getHLCElement(1)!=-1))&&(new_true_start))
			{	
				//if the start and end points of the interval are not same
				if((first_true_logical_time.getHLCElement(0)!=logical_time.getHLCElement(0))||(first_true_logical_time.getHLCElement(1)!=logical_time.getHLCElement(1)))
				{		
					hlcCandidate hlcNewCand = hlcCandidate(id, ++hlcCandCount, first_true_logical_time,logical_time);//create new interval candidate
					hlcCandidateQueue.push(hlcNewCand);	// push the hlc interval candidate into the candidate queue
					new_true_start=false;			// reset interval start
					
					first_true_logical_time.setHLCElement(-1,0);
					first_true_logical_time.setHLCElement(-1,1);

				}
			}
			return 1;
		}
	}
	else	//if the true interval has not ended yet
	{
		/*pushing HVC candidate*/
		Candidate newCand = Candidate(id, ++candCount, augmented_time);
		candidateQueue.push(newCand);
		#ifdef _DEBUG
		// print candidate to debug file
		newCand.print(debug_candidate.at(id));
		debug_candidate.at(id) << endl; 
		#endif	
		
		//decrementing interval size
		true_interval--;
		return 1;
	}
}
/*  Duong: Process:ProcessGlobalToken() - process the global token if that token is at your place right now
                                 i.e. token's ID matches your ID  
      + retrieve next candidate until its color in the token becomes green
        update color for other process accordingly
        and change value of token accordingly (to pass token to other process)
      + if candidate runs out, it just return, but doesn't change value of token
        so that it will be able to process the token in the next run
      + return  WCP_DETECTED if global predicate is found
                WCP_NOT_YET_DETECTED otherwise
*/
int Process::ProcessGlobalToken()
{	bool found_valid_candidate = false;
	bool all_green;
	int whoIsNext;
	// now you are red, i.e. globalToken.color.at(id) = RED
	while(!IsCandidateQueueEmpty())
	{
		bool happen_before = false;
		int  comparison;
		Candidate nextCand = retrieveNextCandidate();
		// replace old candidate by the new one
		globalToken.setProcessCandidate(nextCand, id);
		for(int i = 0; i < number_of_processes; i++)
		{
			if(i != id)
			{	// compare your candidate HVC with other candidate's HVC
				comparison = nextCand.getTimestamp().happenBefore(globalToken.getSnapshot().at(i).getTimestamp(), number_of_processes);
				switch(comparison)
				{	case 1:
						// your HVC happens before other candidte's HVC
						happen_before = true;
						break;
					case -1:
						// other candidate's HVC happens before you// mark other candidate's color as red
						globalToken.setProcessColor(RED, i);
						break;
					default: // concurrent
						break;
				}
				// no need to continue if you know you happen before some other's candidate
				// need to retrieve new candidate
				if(happen_before)
					break;
			}
		} 
		if(happen_before)  // this candidate is not valid
			continue;        // get next candidate if possible
		else
		{              
			// valid candidate// your color is GREEN
			globalToken.setProcessColor(GREEN, id);
			found_valid_candidate = true;
			// no need to retrieve next candidate
			break;
		}
	}
	if(found_valid_candidate)
	{	// you found a valid candidate
		// check if you are the last one that is green
		all_green = true;
		for (int i = 0; i < number_of_processes; i++)
		{
			if(globalToken.getColor().at(i) == RED)
			{	all_green = false;
				whoIsNext = i;
				break;
			}
		}
		if(!all_green)
		{	// there is still some red
			globalToken.setPid(whoIsNext);
		}
		else
		{	// all are green: global predicate is found
			globalToken.setPid(-1);
			return WCP_DETECTED;
		}
	}
	else
	{	// mark globalToken.pid be yourself so that you will continue to hold it at next clock cycle
		globalToken.setPid(id);
		// make sure you are still red
		globalToken.setProcessColor(RED, id);
	}
	// return for considering next candidate
	return WCP_NOT_YET_DETECTED;
}

// check if candidate queue is empty
bool Process::IsCandidateQueueEmpty(){
  return candidateQueue.empty();
}

// retrieve next candidate from candidate queue
Candidate Process::retrieveNextCandidate(){
  Candidate result;

  if(!IsCandidateQueueEmpty()){
    result = candidateQueue.front();
    candidateQueue.pop();
    return result;
  }

  // return NULL;
}

// insert new candidate into candidate queue
void Process::insertNewCandidate(const Candidate & newCand){
  candidateQueue.push(newCand);
}

//.................................................
//................HLC candidate queue functions....
//.................................................

// check if candidate queue is empty
bool Process::IshlcCandidateQueueEmpty(){
  return hlcCandidateQueue.empty();
}

// retrieve next candidate from candidate queue
hlcCandidate Process::retrieveNexthlcCandidate(){
  hlcCandidate result;
  if(!IshlcCandidateQueueEmpty()){
    result = hlcCandidateQueue.front();
    hlcCandidateQueue.pop();
    return result;
  }
  // return NULL;
}

// insert new candidate into candidate queue
void Process::insertNewhlcCandidate(const hlcCandidate & newCand){
  hlcCandidateQueue.push(newCand);
}
//compare current process's candidate with other process's candidate interval to determine overlap
int Process::ininterval(hlcCandidate currenttrueinterval,hlcCandidate x)
{
	//process's candidate interval
	HLC current_inter_begin=currenttrueinterval.getinterval_begin();
	HLC current_inter_end=currenttrueinterval.getinterval_end();
	//getting l and c values of the interval start
	int i1l_begin=current_inter_begin.getHLCElement(0);
	int i1c_begin=current_inter_begin.getHLCElement(1);
	//getting l and c values of the interval end
	int i1l_end=current_inter_end.getHLCElement(0);
	int i1c_end=current_inter_end.getHLCElement(1);
	//other process's candidate interval
	HLC inter_begin=x.getinterval_begin();
	HLC inter_end=x.getinterval_end();
	//getting l and c values of the interval start
	int i2l_begin=inter_begin.getHLCElement(0);
	int i2c_begin=inter_begin.getHLCElement(1);
	//getting l and c values of the interval end
	int i2l_end=inter_end.getHLCElement(0);
	int i2c_end=inter_end.getHLCElement(1);

	if((i1l_end==-1)&&(i1c_end==-1))//if process's candidate interval is empty or not set
	{		
		cout<<"empty current interval case\n";
		return 1;
	}
	else if((i2l_end==-1)&&(i2c_end==-1))//if other process's candidate interval is empty or not set in the global token
	{		
		//cout<<"other process' interval queue is still empty\n";
		return 5;//pass on the token to that process
	}
	else//valid entries for process's and other process's candidate interval
	{
		//cout<<i1l_begin<<":"<<i1c_begin<<";"<<i1l_end<<":"<<i1l_end<<";;"<<i2l_begin<<":"<<i2c_begin<<";"<<i2l_end<<":"<<i2c_end<<"\n";
		if((i1l_begin<i2l_begin)||((i1l_begin==i2l_begin)&&(i1c_begin<=i2c_begin)))//start of i1 comes before/equal start of i2
		{
			if((i1l_end<i2l_begin)||((i1l_end==i2l_begin)&&(i1c_end<=i2c_begin)))//end of i1 comes before start of i2-no overlap
			{
				return 1;
			}
			else //end of i1 comes after start of i2-overlap
			{
				if(((i1l_begin==i2l_begin)&&(i1c_begin==i2c_begin))&&((i1l_end==i2l_end)&&(i1c_end==i2c_end)))//exact match
				{
					return 2;
				}
				else if((i1l_end<i2l_end)||((i1l_end==i2l_end)&&(i1c_end<i2c_end)))//end of i1 comes before end of i2
				{
					return 2;
				}
				else if((i1l_end>i2l_end)||((i1l_end==i2l_end)&&(i1c_end>i2c_end)))//end of i1 comes after end of i2
				{
					return 3;
				}
				else if((i1l_end==i2l_end)&&(i1c_end==i2c_end))//ends of i1 and i2 match
				{
					return 4;
				}
				else
				{
					cout<<"undefined case with values"<<i1l_begin<<","<<i1c_begin<<";"<<i1l_end<<","<<i1c_end<<" "<<i2l_begin<<","<<i2c_begin<<";"<<i2l_end<<","<<i2c_end<<"\n";
				}
			}
		}
		else//start of i1 comes after start of i2
		{
			if((i2l_end<i1l_begin)||((i2l_end==i1l_begin)&&(i2c_end<=i1c_begin)))//end of i2 comes before start of i1-no overlap
			{return 5;}
			else//end of i2 comes after start of i1- overlap
			{
				if((i1l_end>i2l_end)||((i1l_end==i2l_end)&&(i1c_end>i2c_end)))	//end of i1 comes after end of 12
					return 6;
				else								//ends match or end of i2 comes after end of i1
					return 7;
			}
		}
	}
}
/*Process:ProcesshlcGlobalToken() - process the global token if that token is at your(the current process's) place right now
                                 i.e. token's ID matches your ID  
      + retrieve next candidate until you find one that fits into candidate intervals of all other processes
        and change value of token accordingly (to pass token to other process)
      + if candidate runs out, it just return, but doesn't change value of token
        so that it will be able to process the token in the next run
      + return  HLC_WCP_DETECTED if global predicate is found
                HLC_WCP_NOT_YET_DETECTED otherwise
*/
int Process::ProcesshlcGlobalToken(){
	//variables for finding common true interval
	bool found_valid_candidate = false;
	bool pass_on = false;
	//get the candidate intervals in the queue
	std::queue<hlcCandidate> buff=gethlcCandidateQueue();
	//candidate queue not empty
	while(!IshlcCandidateQueueEmpty())
	{
		hlcCandidate hlcnextCand = retrieveNexthlcCandidate();	//get the candidate from the front of the queue
		hlcglobalToken.sethlcProcessCandidate(hlcnextCand, id);	//replace old candidate in the global token with the new one
		int flag=4;						//default flag value 
		for(int i = 0; i < number_of_processes; i++)		//For each process
		{
			found_valid_candidate=false;			//reset variable
			if(i != id)					//compare with all other processes
			{
				//opcit is other_process_candidate_in_token
				hlcCandidate opcit=hlcglobalToken.gethlcSnapshot().at(i);
				hlcCandidate h1,h2;
				HLC x_incr;

				//compare process's candidate with the other process's candidate in the token
				int checkintervalcomparison=ininterval(hlcnextCand,opcit);
				switch(checkintervalcomparison)
				{
					case 1://no overlap - process's candidate is far behind other process's candidate
						//so fetch next candidate
						flag=2;
						break;
					/*overlap cases*/
					case 2://exact match case (or)
						//start of process's candidate comes before start of other process's candidate & 
						//end of process's candidate comes after start and before end of other process's candidate
					case 7://start of process's candidate comes after start of other process's candidate &
						//(ends of process's candidate and other process's candidate match 
						//or end of process's candidate comes before end of other process's candidate)
					case 4://start of process's candidate comes before start of other process's candidate & 
						//and ends match
						
						/*should have altered start according to other process' start -check hlc in multinaive*/

						flag=1;	//compare with next process
						break;

					/*overlap cases that also need interval split- cases 3 & 6*/ 

					case 3://start of process's candidate comes before or equal to start of other process's candidate & 
						//and end of process's candidate comes after end of other process's candidate
						
						//so split the candidate's interval end at the other process' interval end
						//and also alter this process's candidate's interval begin to the other process' interval begin
						x_incr=HLC(vector<int>(2,-1));//variable for creating interval using second piece of the split 
						//new interval starts at the next c value if with (0,9) range, else at the next l value
						if((0<=opcit.getinterval_end().getHLCElement(1)) && (opcit.getinterval_end().getHLCElement(1)<9))
						{	x_incr.setHLCElement((opcit.getinterval_end().getHLCElement(1))+1,1);
							x_incr.setHLCElement(opcit.getinterval_end().getHLCElement(0),0);
						}
						else
						{	x_incr.setHLCElement((opcit.getinterval_end().getHLCElement(0))+1,0);
							x_incr.setHLCElement(0,1);
						}
						//creating interval candidate starting next to other process's candidate's end 
						//and ending at this process's candidate interval's end
						h1 = hlcCandidate(id, ++hlcCandCount, x_incr,hlcnextCand.getinterval_end());
						//push the second piece of the split interval as another candidate interval into process's queue
						hlcCandidateQueue.push(h1);
						//reset process's begin and end to same as other process's
						hlcnextCand.setinterval_end(opcit.getinterval_end());					
						hlcnextCand.setinterval_begin(opcit.getinterval_begin());// because start of this proc can also be before other proc's start// change that only in the candidate 
						hlcglobalToken.sethlcProcessCandidate(hlcnextCand, id);
						//then compare with next process
						flag=1;
						break;
					case 6://start of process's candidate comes after start of other process's candidate &
						//and end of process's candidate comes after start and before end of other process's candidate 
						
						//so split the candidate's interval end at the other process' interval end
						x_incr=HLC(vector<int>(2,-1));//variable for creating interval using second piece of the split 
						//new interval starts at the next c value if with (0,9) range, else at the next l value
						if((0<=opcit.getinterval_end().getHLCElement(1)) && (opcit.getinterval_end().getHLCElement(1)<9))
						{	x_incr.setHLCElement((opcit.getinterval_end().getHLCElement(1))+1,1);
							x_incr.setHLCElement(opcit.getinterval_end().getHLCElement(0),0);
						}
						else
						{	x_incr.setHLCElement((opcit.getinterval_end().getHLCElement(0))+1,0);
							x_incr.setHLCElement(0,1);
						}
						//creating interval candidate starting next to other process's candidate's end 
						//and ending at this process's candidate interval's end
						h1 = hlcCandidate(id, ++hlcCandCount, x_incr,hlcnextCand.getinterval_end());
						//push the second piece of the split interval as another candidate interval into process's queue
						hlcCandidateQueue.push(h1);
						//reset process's end to same as other process's
						hlcnextCand.setinterval_end(opcit.getinterval_end());							 
						hlcglobalToken.sethlcProcessCandidate(hlcnextCand, id);
						//then compare with next process
						flag=1;
						break;
					case 5://other process has not set up any candidate in the token
						//pass token to that process
						hlcglobalToken.sethlcPid(i);
						flag=3;
						break;	
					default:
						//Undefined case
						break;
				}//end of switch
			}//end of if(i!=id)
			/**/
			if(flag==1)//process's interval overlapped with other process's candidate interval so continue comparing with remaining processes
			{	found_valid_candidate=true;
				continue;
			}
			else if(flag==2)//process's interval was far behind other process's candidate interval so break and fetch next candidate
			{	
				found_valid_candidate=false;
				break;
			}
//except for i=number_of_processes
			else if((flag==4)&&(i!=id))//flag value is still the default when compared with a process which is not itself then break
			{
				cout<<"did not fit in any switch cases for"<<i<<"\n";
				found_valid_candidate=false;
				break;
			}
			else if((flag==4)&&(i==id))//flag value is default when compared with itself, as expected, so continue
			{
				continue;
			}
			else if(flag==3)//when the other process's candidate in the Token is not set yet, break and pass token to that process
			{
				pass_on=true;
				break;
				//just exit this while
			}
			else//undefined flag values
			{
				cout<<"undefined flag value: "<<flag<<"\n";
			}
		}//for...all processes
		if((!found_valid_candidate)&&(!pass_on))//exit the while loop only if a overlapping candidate was found or if the token has to be passed on
			continue;
		else
			break;			
	}//while...empty candidate queue of the process
	if(found_valid_candidate)//if found_valid_candidate was true after comparing with all processes
	{
		//cout<<"found candidate\n";
		while(!candidateQueue.empty())//reset your candidate queue
		{candidateQueue.pop();}
		hlcglobalToken.sethlcPid(-1);//reset token owner
		return HLC_WCP_DETECTED;
	}
	/*candidate was not found cases*/
	if(pass_on)//if pass_on was true (token id was already changed in the switch case)
	{
		sethlcCandidateQueue(buff);//restore back the process's candidate queue
		return HLC_WCP_NOT_YET_DETECTED;
	}
	else//pass_on was not true either
	{
		sethlcCandidateQueue(buff);//restore back the process's candidate queue
		hlcglobalToken.sethlcPid((id+1)%(number_of_processes));//pass on the token to the next process
		return HLC_WCP_NOT_YET_DETECTED;
	}

}
